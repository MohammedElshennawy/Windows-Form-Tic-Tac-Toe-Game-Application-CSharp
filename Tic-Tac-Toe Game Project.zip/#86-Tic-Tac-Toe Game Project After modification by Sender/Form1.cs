﻿using _86_Tic_Tac_Toe_Game_Project_After_modification_by_Sender.Properties;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _86_Tic_Tac_Toe_Game_Project_After_modification_by_Sender
{
    public partial class Form1 : Form
    {
        enum enPlayer
        {
            Palyer1,
            Player2
        }

        enum enWinner
        {
            Palyer1,
            Palyer2,
            Draw,
            GameInProgress
        }

        struct stGameStatus
        {
            public enWinner Winner;
            public byte PlayCount;
            public bool GameOver;
        }

        stGameStatus GameStatus;
        enPlayer PlayerTurn = enPlayer.Palyer1;


        public Form1()
        {
            InitializeComponent();
        }


        void ButtonDisable()
        {

            button1.Enabled = false;
            button2.Enabled = false;
            button3.Enabled = false;
            button4.Enabled = false;
            button5.Enabled = false;
            button6.Enabled = false;
            button7.Enabled = false;
            button8.Enabled = false;
            button9.Enabled = false;
        }

        void ButtonEnable()
        {
            button1.Enabled = true;
            button2.Enabled = true;
            button3.Enabled = true;
            button4.Enabled = true;
            button5.Enabled = true;
            button6.Enabled = true;
            button7.Enabled = true;
            button8.Enabled = true;
            button9.Enabled = true;
        }

        void EndGame()
        {
            lbTurnPlayer.Text = "Game Over";

            switch (GameStatus.Winner)
            {
                case enWinner.Palyer1:

                    lbWinPlayer.Text = "Player 1";
                    break;

                case enWinner.Palyer2:

                    lbWinPlayer.Text = "Player 2";
                    break;

                default:

                    lbWinPlayer.Text = "Draw";
                    break;
            }

            MessageBox.Show("Game Over", "GameOver",
                MessageBoxButtons.OK, MessageBoxIcon.Information);


        }

        public bool CheckValue(Button btn1, Button btn2, Button btn3)
        {
            if (btn1.Tag.ToString() != "?" && btn1.Tag.ToString() == btn2.Tag.ToString() && btn1.Tag.ToString() == btn3.Tag.ToString())
            {
                btn1.BackColor = Color.GreenYellow;
                btn2.BackColor = Color.GreenYellow;
                btn3.BackColor = Color.GreenYellow;

                ButtonDisable();

                if (btn1.Tag.ToString() == "X")
                {
                    GameStatus.Winner = enWinner.Palyer1;
                    GameStatus.GameOver = true;
                    EndGame();
                    return true;
                }

                else
                {
                    GameStatus.Winner = enWinner.Palyer2;
                    GameStatus.GameOver = true;
                    EndGame();
                    return true;
                }

            }
            GameStatus.GameOver = false;
            return false;
        }


        public void CheckWinner()
        {
            if (CheckValue(button1, button2, button3))
                return;

            if (CheckValue(button4, button5, button6))
                return;

            if (CheckValue(button7, button8, button9))
                return;

            if (CheckValue(button1, button4, button7))
                return;

            if (CheckValue(button2, button5, button8))
                return;

            if (CheckValue(button3, button6, button9))
                return;

            if (CheckValue(button1, button5, button9))
                return;

            if (CheckValue(button3, button5, button7))
                return;
        }


        public void ChangeImage(Button btn)
        {
            if (btn.Tag.ToString() == "?" && !GameStatus.GameOver)
            {
                switch (PlayerTurn)
                {
                    case enPlayer.Palyer1:

                        btn.Image = Resources.X;
                        btn.Tag = "X";
                        PlayerTurn = enPlayer.Player2;
                        lbTurnPlayer.Text = "Player 2";
                        GameStatus.PlayCount++;
                        CheckWinner();
                        break;

                    case enPlayer.Player2:

                        btn.Image = Resources.O;
                        btn.Tag = "O";
                        PlayerTurn = enPlayer.Palyer1;
                        lbTurnPlayer.Text = "Player 1";
                        GameStatus.PlayCount++;
                        CheckWinner();
                        break;

                }
            }

            else
            {
                MessageBox.Show("Woring Choice", "Woring",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            if (GameStatus.PlayCount == 9 && !GameStatus.GameOver)
            {
                GameStatus.Winner = enWinner.Draw;
                GameStatus.GameOver = true;
                EndGame();
                ButtonDisable();
            }
        }

        private void ResetButton(Button btn)
        {

            btn.Image = Resources.question_mark;
            btn.BackColor = Color.Transparent;
            btn.Tag = "?";

        }

        private void RestartGame()
        {
            ButtonEnable();

            ResetButton(button1);
            ResetButton(button2);
            ResetButton(button3);
            ResetButton(button4);
            ResetButton(button5);
            ResetButton(button6);
            ResetButton(button7);
            ResetButton(button8);
            ResetButton(button9);

            PlayerTurn = enPlayer.Palyer1;
            lbTurnPlayer.Text = "Player 1";
            GameStatus.PlayCount = 0;
            GameStatus.GameOver = false;
            GameStatus.Winner = enWinner.GameInProgress;
            lbWinPlayer.Text = "In Progress";

        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            Color white = Color.FromArgb(255, 255, 255);

            Pen whitePen = new Pen(white, 12);

            whitePen.StartCap = System.Drawing.Drawing2D.LineCap.Round;
            whitePen.EndCap = System.Drawing.Drawing2D.LineCap.Round;

            //draw Horizental lines
            e.Graphics.DrawLine(whitePen, 390, 280, 950, 280);
            e.Graphics.DrawLine(whitePen, 390, 450, 950, 450);
            e.Graphics.DrawLine(whitePen, 570, 120, 570, 610);
            e.Graphics.DrawLine(whitePen, 770, 120, 770, 610);
        }


        private void button_Click(object sender, EventArgs e)
        {
            ChangeImage((Button)sender);
        }

        private void btnRestart_Click(object sender, EventArgs e)
        {
            RestartGame();
        }

    }
}
